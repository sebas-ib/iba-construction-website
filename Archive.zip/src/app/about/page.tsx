import "./about.css";
import Link from "next/link";

export default function About() {
  return (
    <div className="about">
      <div className="hero-section">
        <img src="/about_image.webp" alt="Team working together" />

        <div className="title-card">
          <h1 className="header">About Us</h1>
          <p>
            We are a team of skilled professionals dedicated to providing
            top-quality construction services.
          </p>
        </div>
      </div>

      <div className="our-story">
        <h4>Our Story</h4>
        <h1>Who We Are</h1>
        <p>
          IBA Construction started with a vision to deliver high-quality
          construction services that make a difference. With years of experience
          in the industry, we have earned a reputation for precision and
          customer satisfaction. Our team is passionate about bringing ideas to
          life and creating spaces that people love.
        </p>
      </div>

      <div className="our-values">
        <h4>Our Values</h4>
        <h1>What We Stand For</h1>
        <div className="our-values-box">
          <div className="values-container">
            <div className="value-item">
              <h4>Integrity</h4>
              <p>We maintain honesty and transparency in everything we do.</p>
            </div>
            <div className="value-item">
              <h4>Quality</h4>
              <p>
                We take pride in delivering only the highest quality
                craftsmanship.
              </p>
            </div>
            <div className="value-item">
              <h4>Customer Satisfaction</h4>
              <p>
                Our goal is to exceed our client's expectations in every
                project.
              </p>
            </div>
          </div>
          <div className="right-side">
            <h1>Title</h1>
          </div>
        </div>
      </div>

      {/* <div className="team-section">
        <h1>Meet the Team</h1>
        <div className="team-container">
          <div className="team-member">
            <img
              src="/assets/team1.jpg"
              alt="Team member"
              className="team-img"
            />
            <h4>John Doe</h4>
            <p>Founder & CEO</p>
          </div>
          <div className="team-member">
            <img
              src="/assets/team2.jpg"
              alt="Team member"
              className="team-img"
            />
            <h4>Jane Smith</h4>
            <p>Project Manager</p>
          </div>
          <div className="team-member">
            <img
              src="/assets/team3.jpg"
              alt="Team member"
              className="team-img"
            />
            <h4>Robert Brown</h4>
            <p>Lead Architect</p>
          </div>
        </div>
      </div> */}

      <div className="contact-section">
        <h1>Contact Us</h1>
        <p>
          Interested in working with us? We'd love to hear from you. Get in
          touch with us today, and let's build something great together!
        </p>
        <div className="contact-button">
          <Link href="/contact">Get in Touch</Link>
        </div>
      </div>
    </div>
  );
}
